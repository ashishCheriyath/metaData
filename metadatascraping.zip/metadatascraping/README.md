# metadatascraping
scarpe meta data from given url


///////////////////
1.clone the project 
2.use npm install to install all dependencies

////////////////////
for running using node
$ npm start

for running using nodemon
$ npm test

/////////////////////

for running test script using mocha 
$ npm run testmocha