const scraperepository = require("../repositories/scraperepository");
module.exports.scrapeUrlData = async(req,res)=>{
    try {
        let scrapeUrl = req.body.scrapeurl ? req.body.scrapeurl : "";
        if(scrapeUrl == ""){
            return res.status(422).json({"result":false,"message":"Scrape Url is Misssing"});
        }
        else{
            let scrapedDataResult = await scraperepository.getRelatedDataFromPage(scrapeUrl);
            return res.status(200).json({"result":true,"message":"Fetched Details From Url","data":scrapedDataResult});
        }
        
        
    } catch (error) {
        console.log(error)
        return res.status(400).json({"result":false,"message":"Error in Scarping Data"});
        
    }
}