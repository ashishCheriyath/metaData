var fs      = require('fs');
var request = require('request');
var cheerio = require('cheerio');

var rp = require('request-promise');

module.exports.getRelatedDataFromPage = async(scrapeUrl)=>{
    try {
        let fetchedData = await rp(scrapeUrl);
        var $ = cheerio.load(fetchedData);
        var title, description, keywords,images;
        var json = { title : $("meta[name='title']").attr("content"),
         description : $("meta[name='description']").attr("content"),
         keywords : $("meta[name='keywords']").attr("content"),
        images:$("img").attr("src")};
        return json;
        
    } catch (error) {
        console.log(error);
        throw new Error('Error In Fetching Url Details');
    }
}