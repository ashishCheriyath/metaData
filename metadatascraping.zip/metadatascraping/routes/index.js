var express = require('express');
var router = express.Router();
const scrapeController = require("../controllers/scrapeController");

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.post('/scrapeData', scrapeController.scrapeUrlData );

module.exports = router;
