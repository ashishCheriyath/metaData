var assert = require('assert');
var request = require('request');
// describe('Array', function() {
//   describe('#indexOf()', function() {
//     it('should return -1 when the value is not present', function() {
//       assert.equal([1, 2, 3].indexOf(4), -1);
//     });
//   });
// });

describe('Get Data From meta Data', function() {
  it('Return Scraped Data From Meta Data', function(done) {
      request.post('/scrapeData')
            .send({
              scrapeurl: 'https://www.amazon.in/dp/B07DJ8K2KT?pf_rd_p=38bb1f2f-6b10-4c68-b81f-3cf0c189b8f4&pf_rd_r=HSQV1HTDY8DP2AFGP26X'
          })
          .expect(200)
          .end(function(err, res) {
            console.log(res)
              //expect(res.body).to.have.lengthOf(4);
              done(err);
          });
  });
});